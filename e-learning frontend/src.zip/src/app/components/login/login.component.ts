import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../service/user/user.service';

@Component({
  selector: 'app-login',
  imports: [CommonModule,ReactiveFormsModule,FormsModule,],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit{
  loginForm!:FormGroup;

  constructor(
    private fb: FormBuilder,
    private service: UserService,
    private router: Router,
  ) {}

  ngOnInit(): void {
    // Create the reactive form with validators
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  loginUser(){
    if (this.loginForm.invalid) {
      return;
    }
    const credentials = this.loginForm.value;
    this.service.login(credentials).subscribe(data => {
      console.log(data);
      alert('Login successful!');
      this.router.navigate(['/']);
    });
  }

}
