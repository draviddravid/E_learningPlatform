import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../model/user/user.model';
import { UserService } from '../../service/user/user.service';

@Component({
  selector: 'app-signup',
  imports: [CommonModule,FormsModule,ReactiveFormsModule],
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css'
})
export class SignupComponent implements OnInit{
  signupForm!:FormGroup;

  constructor(private router:Router,
    private fb: FormBuilder,
    private service: UserService,
  ){}

  ngOnInit():void{
    this.signupForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      role:['Student',Validators.required]//Default to student
    });
  }

  onSubmit() {
    if(this.signupForm.invalid){
      return;
    }
    const user:User=this.signupForm.value;
    this.service.register(user).subscribe(() => {
        alert('Sign-up successful!');
        this.router.navigate(['login']);
      });
  }
    

}
